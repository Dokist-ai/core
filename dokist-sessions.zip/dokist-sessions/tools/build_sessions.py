#!/usr/bin/env python3
"""Concatenate sessions/*.md into SESSIONS.md.

Individual files are the source of truth — you edit those.
SESSIONS.md is generated so a stranger can read the whole arc in one scroll.

Usage:  python tools/build_sessions.py
"""
import re, glob, os, datetime

SESSIONS_DIR = "sessions"
OUT = "SESSIONS.md"

PHASES = [
    (0,  0,  None),
    (1,  9,  "System 01 · Legal Intelligence Engine — Sessions 01–09"),
    (10, 15, "System 02 · Research Briefing Agent — Sessions 10–15"),
    (16, 21, "System 03 · Due Diligence Agent · flagship — Sessions 16–21"),
    (22, 33, "Scope 2 · Arabic & French — Sessions 22–33"),
]

def parse(path):
    txt = open(path, encoding="utf-8").read()
    meta, body = {}, txt
    m = re.match(r"^---\n(.*?)\n---\n(.*)$", txt, re.S)
    if m:
        for line in m.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
        body = m.group(2).lstrip("\n")
    meta["_path"] = path
    return meta, body

def main():
    files = sorted(glob.glob(os.path.join(SESSIONS_DIR, "*.md")))
    files = [f for f in files if not os.path.basename(f).startswith("_")]
    entries = [parse(f) for f in files]
    entries.sort(key=lambda e: int(e[0].get("session", 0)))

    done = sum(1 for m, _ in entries if m.get("status") == "done")
    total = len([e for e in entries if int(e[0].get("session", 0)) > 0])
    core_done = sum(1 for m, _ in entries
                    if m.get("status") == "done" and 1 <= int(m.get("session", 0)) <= 21)

    out = []
    out.append("<!-- GENERATED FILE — edit sessions/*.md, then run: python tools/build_sessions.py -->\n")
    out.append("# Engineering Log — DOKIST\n")
    out.append("> What was attempted each session, what actually happened, which decisions were made "
               "and why, and what was still unknown at the end. Written the same evening, every evening.\n")
    out.append(f"**Progress:** {core_done} / 21 core sessions · {done} / {total} total · "
               f"last built {datetime.date.today().isoformat()}\n")

    out.append("| # | Date | System | Status | Entry |")
    out.append("|---|---|---|---|---|")
    for m, _ in entries:
        n = int(m.get("session", 0))
        mark = {"done": "done", "in-progress": "in progress", "not-started": "—"}.get(
            m.get("status", "not-started"), m.get("status"))
        out.append(f"| {n:02d} | {m.get('date') or '—'} | {m.get('system','')} | {mark} | "
                   f"[{os.path.basename(m['_path'])}]({m['_path']}) |")
    out.append("")

    for lo, hi, title in PHASES:
        block = [e for e in entries if lo <= int(e[0].get("session", 0)) <= hi]
        if not block:
            continue
        if title:
            out.append("\n---\n")
            out.append(f"# {title}\n")
        for m, body in block:
            out.append(body.rstrip())
            out.append("\n---\n")

    out.append("*Built with intention. Measured before it ships.*")
    open(OUT, "w", encoding="utf-8").write("\n".join(out))
    print(f"{OUT}: {len(entries)} entries · {core_done}/21 core complete")

if __name__ == "__main__":
    main()
