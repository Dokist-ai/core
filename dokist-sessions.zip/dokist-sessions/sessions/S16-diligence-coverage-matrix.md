---
session: 16
date:
system: due-diligence-agent
branch: feat/s16-coverage-matrix
pr:
status: not-started
---

# Session 16 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s16-coverage-matrix` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): define shared state shapes and materialise the coverage matrix planner
```

---

## Goal

Every shared field and its exact shape written before a node exists. The planner materialises the **full question set before any retrieval runs**. The matrix is a versioned file, not a prompt string. Fix the `coverage` block shape now.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Coverage matrix v1 · a planned run showing the question count before retrieval`

---

## Next session (S17), single goal

Ingestion for both document types, then retrieval routed through the engine's MCP server.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
