---
session: 18
date:
system: due-diligence-agent
branch: feat/s18-evidence-pool
pr:
status: not-started
---

# Session 18 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s18-evidence-pool` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add evidence pool with claim-to-span bindings and fixed-section memo synthesis
```

---

## Goal

Every claim carries its binding or carries none — that fact is the gate's input next session. Fixed sections, strict format instruction, validated after generation. Run ten times; structure identical every time.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`10 sample memos, structure verified · pool schema`

---

## Next session (S19), single goal

Groundedness gate live, and the unsupported-answer study run across both conditions.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
