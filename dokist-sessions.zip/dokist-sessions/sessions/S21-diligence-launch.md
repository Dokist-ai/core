---
session: 21
date:
system: due-diligence-agent
branch: feat/s21-launch
pr:
status: not-started
---

# Session 21 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s21-launch` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): ship UI, benchmark cost and latency over 30 documents, rebuild the portfolio — core programme complete
```

---

## Goal

Real loading states and real error messages. Latency and cost over thirty documents **with definitions stated**. Envelope filled where measured. Portfolio README rebuilt as an index; docs/ finalised including SCOPE-2-ARABIC-FRENCH.md. Demo recorded. Tag v1.0.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Live URL · demo · final metrics.json · restructured README`

---

## Next session (S22), single goal

**Recovery week, then Scope 2.** Bulletin Officiel scraper with edition, language and date metadata.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
