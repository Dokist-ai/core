---
session: 30
date:
system: ma-bench
branch: test/s30-benchmark-v0
pr:
status: not-started
---

# Session 30 — ____-__-__ — ma-bench

*Scope 2 · Arabic & French*

**Branch:** `test/s30-benchmark-v0` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-bench): complete jurist verification pass and publish benchmark v0.1
```

---

## Goal

Verified pairs only. **Rejection rate recorded and published** — itself a finding about model-drafted legal questions. Court decisions pseudonymised. Dataset card names the verifier, the method and the limitations.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Dataset on the Hub · rejection rate · dataset card`

---

## Next session (S31), single goal

Three embedding models × hybrid on/off, one table, intervals computed.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
