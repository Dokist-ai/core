---
session: 25
date:
system: ma-ocr
branch: feat/s25-ocr-bakeoff
pr:
status: not-started
---

# Session 25 — ____-__-__ — ma-ocr

*Scope 2 · Arabic & French*

**Branch:** `feat/s25-ocr-bakeoff` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-ocr): run five-system Arabic OCR bake-off with CER and cost per page
```

---

## Goal

Tesseract, an open pipeline model, a self-hosted VLM, an Arabic-specific fine-tune, one commercial API. Same 200 pages, same metrics. **Broken down by page type, never averaged into one figure.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/ocr_bakeoff.json + results table`

---

## Next session (S26), single goal

Three-tier routing layer with per-page confidence and cost accounting.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
