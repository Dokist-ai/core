---
session: 27
date:
system: ma-norm
branch: feat/s27-arabic-normalisation
pr:
status: not-started
---

# Session 27 — ____-__-__ — ma-norm

*Scope 2 · Arabic & French*

**Branch:** `feat/s27-arabic-normalisation` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-norm): add Arabic normalisation pipeline and Hijri/Gregorian date parser
```

---

## Goal

CAMeL Tools normalisation with a **before/after retrieval measurement** on a fixed query set. Dual-calendar parser with unit tests against real BO dates. **Jurist booked for Session 30 before this session ends.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Before/after retrieval table · date parser fixtures`

---

## Next session (S28), single goal

Arabic/French aligned pairs mined from the paired Bulletin Officiel editions.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
