---
session:
date:
system:
branch:
pr:
status: not-started
---

# Session __ — ____-__-__ — <system>

**Branch:** `<type>/s__-<slug>` · **PR:** #___

**Commit subject:**
```
<type>(<system>): <outcome in the imperative, lowercase, no full stop>
```

---

## Goal

<One sentence. This is tonight's definition of success.>

---

## What happened

-

## The number

______ · **n = ______** · definition: ______

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

## Decision made

______

## Evidence committed

`evidence/______`

---

## Next session, single goal

______
