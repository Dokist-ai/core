---
session: 19
date:
system: due-diligence-agent
branch: feat/s19-groundedness-gate
pr:
status: not-started
---

# Session 19 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s19-groundedness-gate` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add groundedness gate and publish the unsupported-answer study
```

---

## Goal

Unbound claims **flagged and emitted, never suppressed**. Two conditions, one question set, claim-level scoring. Hand-check 20% and record the agreement rate. Claim count, memo count and coverage block all reported. Write **ADR-003**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/unsupported_answers_study.md + raw scores · adr/003-surface-unsupported.md`

---

## Next session (S20), single goal

Production layer carried over from System 02, eval gate set against the interval, 20 adversarial inputs.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
