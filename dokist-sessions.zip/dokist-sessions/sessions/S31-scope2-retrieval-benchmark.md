---
session: 31
date:
system: ma-retrieval
branch: feat/s31-retrieval-benchmark
pr:
status: not-started
---

# Session 31 — ____-__-__ — ma-retrieval

*Scope 2 · Arabic & French*

**Branch:** `feat/s31-retrieval-benchmark` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-retrieval): benchmark three embedding models with and without hybrid retrieval
```

---

## Goal

Dense-only versus BM25-plus-dense, three models, normalised and unnormalised text. **Intervals computed before any comparative sentence is written.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Retrieval table with intervals · raw runs`

---

## Next session (S32), single goal

Cross-lingual FR→AR retrieval scored with the same metrics as the monolingual task.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
