---
session: 5
date:
system: legal-intelligence-engine
branch: test/s05-red-team
pr:
status: not-started
---

# Session 05 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `test/s05-red-team` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(legal-engine): add 15 adversarial tests and the antonym-collision probe set
```

---

## Goal

Instruction override, out-of-scope, false-premise questions, requests for legal advice, unanswerable queries, injection in the document body. Plus clause pairs that read alike and mean the opposite. Five failure modes documented with mitigations.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/red_team.json · evidence/failure_analysis.md`

---

## Next session (S06), single goal

Training environment validated on a 10% subset, then rank 4/8/16 launched with identical seed and data.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
