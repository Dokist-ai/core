---
session: 26
date:
system: ma-ocr
branch: feat/s26-ocr-router
pr:
status: not-started
---

# Session 26 — ____-__-__ — ma-ocr

*Scope 2 · Arabic & French*

**Branch:** `feat/s26-ocr-router` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-ocr): add three-tier OCR routing layer with per-page confidence and cost accounting
```

---

## Goal

Text-layer detection, then engine selection by page type, then per-page cost logged. **The router is the product; the engines are interchangeable.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Router run with paid-tier share and cost per page visible`

---

## Next session (S27), single goal

Arabic normalisation with a measured before/after, and the dual-calendar parser.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
