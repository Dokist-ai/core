---
session: 20
date:
system: due-diligence-agent
branch: docs/s20-hardening
pr:
status: not-started
---

# Session 20 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `docs/s20-hardening` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
docs(due-diligence): add production layer, 20-input adversarial suite, eval gate and two ADRs
```

---

## Goal

Docker and CI **copied from System 02, not rewritten**. Eval gate threshold computed against the interval, reasoning commented in the workflow. Twenty adversarial inputs; every crash fixed; `blocked` demonstrated on a corrupt PDF. Write **ADR-001 and ADR-002**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Adversarial suite results · .github/workflows/eval.yml · 2 ADRs`

---

## Next session (S21), single goal

UI, 30-document cost and latency benchmark, portfolio README rebuilt as an index.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
