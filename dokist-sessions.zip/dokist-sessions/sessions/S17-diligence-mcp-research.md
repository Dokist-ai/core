---
session: 17
date:
system: due-diligence-agent
branch: feat/s17-mcp-research
pr:
status: not-started
---

# Session 17 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s17-mcp-research` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add ingestion agent and route retrieval through the Legal Intelligence Engine over MCP
```

---

## Goal

One entry point serves an NDA **and** a loan application — reuse System 01's pipeline, do not rewrite it. Retrieval through MCP, not a function call. `insufficient_evidence` recorded as a gap, never retried blindly.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Both document types ingested · trace showing the MCP call inside the agent run`

---

## Next session (S18), single goal

Evidence pool with claim-to-span bindings, and a memo whose structure is identical across ten runs.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
