---
session: 14
date:
system: research-briefing-agent
branch: test/s14-ci
pr:
status: not-started
---

# Session 14 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `test/s14-ci` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(research-agent): add 14 pytest tests with mocked LLM and search calls, wire GitHub Actions CI
```

---

## Goal

Patch **at the call site**, not the definition site. **Deliberately break one function and confirm the relevant test goes red.** Lint → test → deploy gated on main. Write **ADR-003**. CI badge only after this merges green.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Green CI run URL · test output · adr/003-mock-every-external-call.md`

---

## Next session (S15), single goal

Reliability harness over a fixed topic set: every tool call recorded with outcome, cause and latency.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
