---
session: 29
date:
system: ma-bench
branch: test/s29-benchmark-candidates
pr:
status: not-started
---

# Session 29 — ____-__-__ — ma-bench

*Scope 2 · Arabic & French*

**Branch:** `test/s29-benchmark-candidates` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-bench): generate 500 candidate question–answer pairs from BO and cassation sources
```

---

## Goal

Model-drafted candidates from source passages, each carrying its exact source span. **Candidates only — nothing enters the benchmark until a jurist has passed it.** Sending the pack is this session's deliverable.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Candidate pack sent · send date recorded`

---

## Next session (S30), single goal

Jurist verification pass complete and benchmark v0.1 published with its card.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
