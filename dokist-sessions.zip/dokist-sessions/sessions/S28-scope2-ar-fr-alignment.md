---
session: 28
date:
system: ma-corpus
branch: feat/s28-ar-fr-alignment
pr:
status: not-started
---

# Session 28 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `feat/s28-ar-fr-alignment` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-corpus): mine Arabic/French aligned pairs from paired Bulletin Officiel editions
```

---

## Goal

Match Arabic general-edition instruments to their French translation-edition counterparts by instrument number and date, then align at article level. Manual spot-check recorded.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Aligned corpus + spot-check record`

---

## Next session (S29), single goal

500 candidate question–answer pairs drafted and sent to the verifier.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
