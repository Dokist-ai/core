---
session: 22
date:
system: ma-corpus
branch: feat/s22-bo-scraper
pr:
status: not-started
---

# Session 22 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `feat/s22-bo-scraper` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-corpus): add Bulletin Officiel scraper with edition, language and date metadata
```

---

## Goal

Rate-limited, cached, resumable, robots.txt respected. Every issue records edition type, language, issue number and Gregorian/Hijri date. Acquisition only — no parsing. **Settle the licensing and ToS position this session and record it.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Raw PDF store on the external SSD · licensing note in the repo`

---

## Next session (S23), single goal

Text-layer inventory across the archive — the number that sets the entire OCR budget.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
