---
session: 24
date:
system: ma-corpus
branch: test/s24-ocr-ground-truth
pr:
status: not-started
---

# Session 24 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `test/s24-ocr-ground-truth` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-corpus): add 200-page hand-verified Arabic OCR ground truth set
```

---

## Goal

Stratified: clean single-column, multi-column, tables, degraded scan, mixed RTL/LTR. No code this session. **This is Scope 2's Session 03 and it is worth exactly as much.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/ocr_ground_truth/`

---

## Next session (S25), single goal

Five OCR systems compared on identical pages, reported by page type.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
