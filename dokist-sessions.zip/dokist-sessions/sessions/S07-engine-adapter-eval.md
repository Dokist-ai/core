---
session: 7
date:
system: legal-intelligence-engine
branch: feat/s07-adapter-eval
pr:
status: not-started
---

# Session 07 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s07-adapter-eval` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): evaluate all adapters on the golden set with intervals, publish two models
```

---

## Goal

Build the output parser, test on five examples, confirm non-zero before running all forty. Score on the same golden set. **Compute the interval before writing any comparative sentence.** Publish two models with cards.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Ablation table with 95% intervals · 2 model pages live`

---

## Next session (S08), single goal

Hard negatives mined from colliding clause pairs, embedding model trained locally, Recall benchmarked.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>
