<!-- GENERATED FILE — edit sessions/*.md, then run: python tools/build_sessions.py -->

# Engineering Log — DOKIST

> What was attempted each session, what actually happened, which decisions were made and why, and what was still unknown at the end. Written the same evening, every evening.

**Progress:** 0 / 21 core sessions · 1 / 33 total · last built 2026-08-10

| # | Date | System | Status | Entry |
|---|---|---|---|---|
| 00 | 2026-08-10 | repository | done | [S00-repository-triage.md](sessions/S00-repository-triage.md) |
| 01 | — | legal-intelligence-engine | — | [S01-engine-ingestion.md](sessions/S01-engine-ingestion.md) |
| 02 | — | legal-intelligence-engine | — | [S02-engine-response-contract.md](sessions/S02-engine-response-contract.md) |
| 03 | — | legal-intelligence-engine | — | [S03-engine-golden-set.md](sessions/S03-engine-golden-set.md) |
| 04 | — | legal-intelligence-engine | — | [S04-engine-ragas-harness.md](sessions/S04-engine-ragas-harness.md) |
| 05 | — | legal-intelligence-engine | — | [S05-engine-red-team.md](sessions/S05-engine-red-team.md) |
| 06 | — | legal-intelligence-engine | — | [S06-engine-train-env-ablation.md](sessions/S06-engine-train-env-ablation.md) |
| 07 | — | legal-intelligence-engine | — | [S07-engine-adapter-eval.md](sessions/S07-engine-adapter-eval.md) |
| 08 | — | legal-intelligence-engine | — | [S08-engine-embeddings.md](sessions/S08-engine-embeddings.md) |
| 09 | — | legal-intelligence-engine | — | [S09-engine-mcp-server.md](sessions/S09-engine-mcp-server.md) |
| 10 | — | research-briefing-agent | — | [S10-briefing-agent-state.md](sessions/S10-briefing-agent-state.md) |
| 11 | — | research-briefing-agent | — | [S11-briefing-degradation-paths.md](sessions/S11-briefing-degradation-paths.md) |
| 12 | — | research-briefing-agent | — | [S12-briefing-service-contract.md](sessions/S12-briefing-service-contract.md) |
| 13 | — | research-briefing-agent | — | [S13-briefing-docker.md](sessions/S13-briefing-docker.md) |
| 14 | — | research-briefing-agent | — | [S14-briefing-ci.md](sessions/S14-briefing-ci.md) |
| 15 | — | research-briefing-agent | — | [S15-briefing-reliability-benchmark.md](sessions/S15-briefing-reliability-benchmark.md) |
| 16 | — | due-diligence-agent | — | [S16-diligence-coverage-matrix.md](sessions/S16-diligence-coverage-matrix.md) |
| 17 | — | due-diligence-agent | — | [S17-diligence-mcp-research.md](sessions/S17-diligence-mcp-research.md) |
| 18 | — | due-diligence-agent | — | [S18-diligence-evidence-pool.md](sessions/S18-diligence-evidence-pool.md) |
| 19 | — | due-diligence-agent | — | [S19-diligence-groundedness-gate.md](sessions/S19-diligence-groundedness-gate.md) |
| 20 | — | due-diligence-agent | — | [S20-diligence-hardening.md](sessions/S20-diligence-hardening.md) |
| 21 | — | due-diligence-agent | — | [S21-diligence-launch.md](sessions/S21-diligence-launch.md) |
| 22 | — | ma-corpus | — | [S22-scope2-bo-scraper.md](sessions/S22-scope2-bo-scraper.md) |
| 23 | — | ma-corpus | — | [S23-scope2-text-layer-inventory.md](sessions/S23-scope2-text-layer-inventory.md) |
| 24 | — | ma-corpus | — | [S24-scope2-ocr-ground-truth.md](sessions/S24-scope2-ocr-ground-truth.md) |
| 25 | — | ma-ocr | — | [S25-scope2-ocr-bakeoff.md](sessions/S25-scope2-ocr-bakeoff.md) |
| 26 | — | ma-ocr | — | [S26-scope2-ocr-router.md](sessions/S26-scope2-ocr-router.md) |
| 27 | — | ma-norm | — | [S27-scope2-arabic-normalisation.md](sessions/S27-scope2-arabic-normalisation.md) |
| 28 | — | ma-corpus | — | [S28-scope2-ar-fr-alignment.md](sessions/S28-scope2-ar-fr-alignment.md) |
| 29 | — | ma-bench | — | [S29-scope2-benchmark-candidates.md](sessions/S29-scope2-benchmark-candidates.md) |
| 30 | — | ma-bench | — | [S30-scope2-benchmark-v0.md](sessions/S30-scope2-benchmark-v0.md) |
| 31 | — | ma-retrieval | — | [S31-scope2-retrieval-benchmark.md](sessions/S31-scope2-retrieval-benchmark.md) |
| 32 | — | ma-retrieval | — | [S32-scope2-cross-lingual.md](sessions/S32-scope2-cross-lingual.md) |
| 33 | — | ma-bench | — | [S33-scope2-release.md](sessions/S33-scope2-release.md) |

# Session 00 — 2026-08-10 — repository

> **This one is filled in as a worked example.** Delete it once you have three real entries,
> or keep it — Session 00 genuinely happened.

**Branch:** `chore/s00-triage` · **PR:** [#52](../../../pull/52)

**Goal:** Clear the CI build blocking PR #52, settle repository identity, and get the machine
above 40 GB free before Session 01.

**What happened:**
- Docker build failed: `legal-intelligence-engine/requirements.txt` missing at COPY time. Added the file.
- Build then succeeded, but cache export runs ~15 min. Kept `cache-to: type=gha` for now.
- Added `CITATION.cff` at repository root — GitHub only renders the citation button from root.
- Disk: 6.27 GB → 44 GB free after clearing simulator and Homebrew caches. `HF_HOME` and
  `PIP_CACHE_DIR` redirected to the external SSD.

**The number:** free disk 44 GB (target 40 GB) · **n = 1 machine** · definition: `df -h /` available.

**Cost:** $0

**Blocker hit:**
```
ERROR: failed to solve: failed to compute cache key:
"/legal-intelligence-engine/requirements.txt": not found
```
Cause: `COPY` in Docker resolves against the build context, not the filesystem root. Twenty minutes lost.

**Dead end:** Tried moving the Dockerfile into the system folder to fix the path — broke
`docker-compose.yml`'s context. Reverted; fixed the path in the COPY instead.

**Decision made:** Skip `push: true` on PR builds to save cache time — deferred, not urgent.
`version` and `doi` go into `CITATION.cff` only after the first stable release tag, per
non-negotiable #3.

**Evidence committed:** none — infrastructure session.

**Next session (S01), single goal:** Clause-aware ingestion running end to end over 50 CUAD
contracts, every chunk carrying `doc_id`, `page`, `char_start`, `char_end`.

---


---

# System 01 · Legal Intelligence Engine — Sessions 01–09

# Session 01 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s01-ingestion` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): add clause-aware ingestion with page and character-span metadata
```

---

## Goal

Ingestion running end to end over 50 CUAD contracts plus an EDGAR and EUR-Lex sample. Split on clause boundaries, parent heading in metadata, every chunk carrying `doc_id`, `page`, `char_start`, `char_end`. Print ten chunks and read them.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/ingest_stats.json`

---

## Next session (S02), single goal

Four statuses written as a table, then the retrieval chain and citation contract built against them.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 02 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s02-response-contract` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): add retrieval chain and four-status response contract with span binding
```

---

## Goal

Statuses written **before** the retrieval code: `grounded`, `insufficient_evidence`, `ambiguous_scope`, `out_of_corpus`. k=8 reranked to 3. Similarity floor enforced. `out_of_corpus` rejected pre-generation.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/transcripts/ — one worked transcript per status`

---

## Next session (S03), single goal

40 hand-written questions with ground truth and the exact span each must bind to.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 03 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `test/s03-golden-set` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(legal-engine): add 40-question golden dataset with ground truth and source spans
```

---

## Goal

No new code. Forty questions written by hand: 25 answerable, 10 requiring synthesis across clauses, 5 genuinely unanswerable. **Do not generate these with a model.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/golden_dataset.json`

---

## Next session (S04), single goal

RAGAS harness running unattended across four retrieval configurations, n recorded per config.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 04 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s04-ragas-harness` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): add RAGAS harness and four-configuration retrieval comparison
```

---

## Goal

Smoke-test on 5 samples and confirm non-zero scores before the full run. Four configs, config hash + timestamp + n per config. Write **ADR-002 (clause-aware chunking)** while the run executes.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/eval_runs/<date>/ · adr/002-clause-aware-chunking.md`

---

## Next session (S05), single goal

15 adversarial prompts plus the antonym-collision probe set, run and catalogued.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 05 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `test/s05-red-team` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(legal-engine): add 15 adversarial tests and the antonym-collision probe set
```

---

## Goal

Instruction override, out-of-scope, false-premise questions, requests for legal advice, unanswerable queries, injection in the document body. Plus clause pairs that read alike and mean the opposite. Five failure modes documented with mitigations.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/red_team.json · evidence/failure_analysis.md`

---

## Next session (S06), single goal

Training environment validated on a 10% subset, then rank 4/8/16 launched with identical seed and data.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 06 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `chore/s06-train-env-ablation` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
chore(legal-engine): configure 4-bit training environment and launch LoRA rank 4/8/16 ablation
```

---

## Goal

Quantised loading and gradient checkpointing verified on 10% before anything long starts. Three runs, **only rank varies**. Launch at 0:15 and write the Session 08 mining script while it trains.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`3 adapters · per-run training time and peak memory`

---

## Next session (S07), single goal

Adapters parsed, scored on the golden set, intervals computed, two models published.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 07 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s07-adapter-eval` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): evaluate all adapters on the golden set with intervals, publish two models
```

---

## Goal

Build the output parser, test on five examples, confirm non-zero before running all forty. Score on the same golden set. **Compute the interval before writing any comparative sentence.** Publish two models with cards.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Ablation table with 95% intervals · 2 model pages live`

---

## Next session (S08), single goal

Hard negatives mined from colliding clause pairs, embedding model trained locally, Recall benchmarked.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 08 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s08-embeddings` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): train domain-adapted embedding model with hard negative mining
```

---

## Goal

Negatives mined from the pairs S05 showed colliding. **Print twenty triplets and read them** — this is the unacceptable cut. Train locally. Benchmark Recall@3, Recall@5, MRR against both baselines, query count stated. Write **ADR-001**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Embedding comparison table · trained model · adr/001-domain-adapted-embeddings.md`

---

## Next session (S09), single goal

MCP server exposed and verified from a real client; index built; eval gate wired; System 01 shipped.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 09 — ____-__-__ — legal-intelligence-engine

*System 01 · Legal Intelligence Engine*

**Branch:** `feat/s09-mcp-server` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(legal-engine): expose retrieval as an MCP server, gate CI on eval, publish envelope — System 01 complete
```

---

## Goal

Three typed tools verified from a real MCP client, with a screenshot. **Launch the 2,438-doc index build in the background**, then write ADR-003, METHODOLOGY.md and LIMITATIONS.md while it runs. Eval gate at Recall@3 ≥ 0.80, faithfulness ≥ 0.82. Envelope published with the ~10k row marked `not measured`. Tag v1.0.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Client screenshot · envelope table · .github/workflows/eval.yml · evidence/metrics.json`

---

## Next session (S10), single goal

AgentState written in full with types, then the research node returning structured notes.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---


---

# System 02 · Research Briefing Agent — Sessions 10–15

# Session 10 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `feat/s10-agent-state` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(research-agent): define AgentState schema and research node with web search
```

---

## Goal

The TypedDict **complete before any node code** — including `status`, `tool_calls` and `retrieved_at`. Then the research node: topic in, structured notes with source URLs out.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Notebook run showing structured notes for 3 topics`

---

## Next session (S11), single goal

Synthesis node wired, and the backoff / fallback / degrade branches built alongside the happy path.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 11 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `feat/s11-degradation-paths` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(research-agent): add synthesis node and wire bounded backoff, fallback and degradation into the graph
```

---

## Goal

Both nodes in a StateGraph. **Build the failure branches now, not later.** Verify by forcing a tool to fail and confirming the run terminates in `degraded` with a gap list. Tracing on, both nodes visible. Write **ADR-002**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/traces/ · forced-failure trace · adr/002-degrade-not-retry.md`

---

## Next session (S12), single goal

FastAPI layer with Pydantic models and the three-status contract; tool_calls on every response.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 12 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `feat/s12-service-contract` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(research-agent): add FastAPI service layer with typed models and three-status response contract
```

---

## Goal

`complete` / `degraded` / `failed`. No raw dictionaries at the boundary. `tool_calls` emitted on **every** response, not only on failure. Typed errors, health endpoint, request ID per log line.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`OpenAPI schema committed`

---

## Next session (S13), single goal

ARM64 container with a cached dependency layer, running from an env file, no secrets in the image.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 13 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `build/s13-docker` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
build(research-agent): containerise service with ARM64 Dockerfile and layered dependency cache
```

---

## Goal

Requirements copied before source so the install layer caches. Built natively for ARM64 — confirm the image architecture after the build. Image size recorded.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Build log with image size`

---

## Next session (S14), single goal

14 tests with every external call mocked at the call site, and CI green on push.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 14 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `test/s14-ci` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(research-agent): add 14 pytest tests with mocked LLM and search calls, wire GitHub Actions CI
```

---

## Goal

Patch **at the call site**, not the definition site. **Deliberately break one function and confirm the relevant test goes red.** Lint → test → deploy gated on main. Write **ADR-003**. CI badge only after this merges green.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Green CI run URL · test output · adr/003-mock-every-external-call.md`

---

## Next session (S15), single goal

Reliability harness over a fixed topic set: every tool call recorded with outcome, cause and latency.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 15 — ____-__-__ — research-briefing-agent

*System 02 · Research Briefing Agent*

**Branch:** `feat/s15-reliability-benchmark` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(research-agent): add reliability harness measuring tool-call success and latency percentiles — System 02 complete
```

---

## Goal

Live sources, every call recorded with **cause** on failure: timeout / rate limit / malformed / empty. Latency definition stated explicitly. Envelope measured row filled, ~20 and ~50 marked `not measured`. Deploy, demo, tag v1.0. Write **ADR-001**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/reliability_run.json · metrics.json · adr/001-measure-tool-calls.md`

---

## Next session (S16), single goal

Shared state shapes fixed, then the coverage matrix materialised before any retrieval.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---


---

# System 03 · Due Diligence Agent · flagship — Sessions 16–21

# Session 16 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s16-coverage-matrix` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): define shared state shapes and materialise the coverage matrix planner
```

---

## Goal

Every shared field and its exact shape written before a node exists. The planner materialises the **full question set before any retrieval runs**. The matrix is a versioned file, not a prompt string. Fix the `coverage` block shape now.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Coverage matrix v1 · a planned run showing the question count before retrieval`

---

## Next session (S17), single goal

Ingestion for both document types, then retrieval routed through the engine's MCP server.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 17 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s17-mcp-research` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add ingestion agent and route retrieval through the Legal Intelligence Engine over MCP
```

---

## Goal

One entry point serves an NDA **and** a loan application — reuse System 01's pipeline, do not rewrite it. Retrieval through MCP, not a function call. `insufficient_evidence` recorded as a gap, never retried blindly.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Both document types ingested · trace showing the MCP call inside the agent run`

---

## Next session (S18), single goal

Evidence pool with claim-to-span bindings, and a memo whose structure is identical across ten runs.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 18 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s18-evidence-pool` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add evidence pool with claim-to-span bindings and fixed-section memo synthesis
```

---

## Goal

Every claim carries its binding or carries none — that fact is the gate's input next session. Fixed sections, strict format instruction, validated after generation. Run ten times; structure identical every time.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`10 sample memos, structure verified · pool schema`

---

## Next session (S19), single goal

Groundedness gate live, and the unsupported-answer study run across both conditions.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 19 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s19-groundedness-gate` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): add groundedness gate and publish the unsupported-answer study
```

---

## Goal

Unbound claims **flagged and emitted, never suppressed**. Two conditions, one question set, claim-level scoring. Hand-check 20% and record the agreement rate. Claim count, memo count and coverage block all reported. Write **ADR-003**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/unsupported_answers_study.md + raw scores · adr/003-surface-unsupported.md`

---

## Next session (S20), single goal

Production layer carried over from System 02, eval gate set against the interval, 20 adversarial inputs.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 20 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `docs/s20-hardening` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
docs(due-diligence): add production layer, 20-input adversarial suite, eval gate and two ADRs
```

---

## Goal

Docker and CI **copied from System 02, not rewritten**. Eval gate threshold computed against the interval, reasoning commented in the workflow. Twenty adversarial inputs; every crash fixed; `blocked` demonstrated on a corrupt PDF. Write **ADR-001 and ADR-002**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Adversarial suite results · .github/workflows/eval.yml · 2 ADRs`

---

## Next session (S21), single goal

UI, 30-document cost and latency benchmark, portfolio README rebuilt as an index.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 21 — ____-__-__ — due-diligence-agent

*System 03 · Due Diligence Agent · flagship*

**Branch:** `feat/s21-launch` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(due-diligence): ship UI, benchmark cost and latency over 30 documents, rebuild the portfolio — core programme complete
```

---

## Goal

Real loading states and real error messages. Latency and cost over thirty documents **with definitions stated**. Envelope filled where measured. Portfolio README rebuilt as an index; docs/ finalised including SCOPE-2-ARABIC-FRENCH.md. Demo recorded. Tag v1.0.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Live URL · demo · final metrics.json · restructured README`

---

## Next session (S22), single goal

**Recovery week, then Scope 2.** Bulletin Officiel scraper with edition, language and date metadata.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---


---

# Scope 2 · Arabic & French — Sessions 22–33

# Session 22 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `feat/s22-bo-scraper` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-corpus): add Bulletin Officiel scraper with edition, language and date metadata
```

---

## Goal

Rate-limited, cached, resumable, robots.txt respected. Every issue records edition type, language, issue number and Gregorian/Hijri date. Acquisition only — no parsing. **Settle the licensing and ToS position this session and record it.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Raw PDF store on the external SSD · licensing note in the repo`

---

## Next session (S23), single goal

Text-layer inventory across the archive — the number that sets the entire OCR budget.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 23 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `docs/s23-text-layer-inventory` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
docs(ma-corpus): publish text-layer inventory across the Bulletin Officiel archive
```

---

## Goal

One question: how many pages carry an extractable text layer, and from what year does that begin. Deliverable is a chart and a public write-up. **Nobody has published this.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Inventory chart + write-up`

---

## Next session (S24), single goal

200 hand-verified pages of Arabic OCR ground truth, stratified by page type.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 24 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `test/s24-ocr-ground-truth` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-corpus): add 200-page hand-verified Arabic OCR ground truth set
```

---

## Goal

Stratified: clean single-column, multi-column, tables, degraded scan, mixed RTL/LTR. No code this session. **This is Scope 2's Session 03 and it is worth exactly as much.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/ocr_ground_truth/`

---

## Next session (S25), single goal

Five OCR systems compared on identical pages, reported by page type.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 25 — ____-__-__ — ma-ocr

*Scope 2 · Arabic & French*

**Branch:** `feat/s25-ocr-bakeoff` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-ocr): run five-system Arabic OCR bake-off with CER and cost per page
```

---

## Goal

Tesseract, an open pipeline model, a self-hosted VLM, an Arabic-specific fine-tune, one commercial API. Same 200 pages, same metrics. **Broken down by page type, never averaged into one figure.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`evidence/ocr_bakeoff.json + results table`

---

## Next session (S26), single goal

Three-tier routing layer with per-page confidence and cost accounting.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 26 — ____-__-__ — ma-ocr

*Scope 2 · Arabic & French*

**Branch:** `feat/s26-ocr-router` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-ocr): add three-tier OCR routing layer with per-page confidence and cost accounting
```

---

## Goal

Text-layer detection, then engine selection by page type, then per-page cost logged. **The router is the product; the engines are interchangeable.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Router run with paid-tier share and cost per page visible`

---

## Next session (S27), single goal

Arabic normalisation with a measured before/after, and the dual-calendar parser.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 27 — ____-__-__ — ma-norm

*Scope 2 · Arabic & French*

**Branch:** `feat/s27-arabic-normalisation` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-norm): add Arabic normalisation pipeline and Hijri/Gregorian date parser
```

---

## Goal

CAMeL Tools normalisation with a **before/after retrieval measurement** on a fixed query set. Dual-calendar parser with unit tests against real BO dates. **Jurist booked for Session 30 before this session ends.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Before/after retrieval table · date parser fixtures`

---

## Next session (S28), single goal

Arabic/French aligned pairs mined from the paired Bulletin Officiel editions.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 28 — ____-__-__ — ma-corpus

*Scope 2 · Arabic & French*

**Branch:** `feat/s28-ar-fr-alignment` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-corpus): mine Arabic/French aligned pairs from paired Bulletin Officiel editions
```

---

## Goal

Match Arabic general-edition instruments to their French translation-edition counterparts by instrument number and date, then align at article level. Manual spot-check recorded.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Aligned corpus + spot-check record`

---

## Next session (S29), single goal

500 candidate question–answer pairs drafted and sent to the verifier.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 29 — ____-__-__ — ma-bench

*Scope 2 · Arabic & French*

**Branch:** `test/s29-benchmark-candidates` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-bench): generate 500 candidate question–answer pairs from BO and cassation sources
```

---

## Goal

Model-drafted candidates from source passages, each carrying its exact source span. **Candidates only — nothing enters the benchmark until a jurist has passed it.** Sending the pack is this session's deliverable.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Candidate pack sent · send date recorded`

---

## Next session (S30), single goal

Jurist verification pass complete and benchmark v0.1 published with its card.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 30 — ____-__-__ — ma-bench

*Scope 2 · Arabic & French*

**Branch:** `test/s30-benchmark-v0` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
test(ma-bench): complete jurist verification pass and publish benchmark v0.1
```

---

## Goal

Verified pairs only. **Rejection rate recorded and published** — itself a finding about model-drafted legal questions. Court decisions pseudonymised. Dataset card names the verifier, the method and the limitations.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Dataset on the Hub · rejection rate · dataset card`

---

## Next session (S31), single goal

Three embedding models × hybrid on/off, one table, intervals computed.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 31 — ____-__-__ — ma-retrieval

*Scope 2 · Arabic & French*

**Branch:** `feat/s31-retrieval-benchmark` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-retrieval): benchmark three embedding models with and without hybrid retrieval
```

---

## Goal

Dense-only versus BM25-plus-dense, three models, normalised and unnormalised text. **Intervals computed before any comparative sentence is written.**

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Retrieval table with intervals · raw runs`

---

## Next session (S32), single goal

Cross-lingual FR→AR retrieval scored with the same metrics as the monolingual task.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 32 — ____-__-__ — ma-retrieval

*Scope 2 · Arabic & French*

**Branch:** `feat/s32-cross-lingual` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
feat(ma-retrieval): evaluate cross-lingual FR→AR retrieval on the benchmark
```

---

## Goal

French questions against the Arabic authoritative corpus. Same metrics as Task 1, so the cross-lingual penalty is legible **as a number rather than an impression**.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Cross-lingual results beside the monolingual baseline`

---

## Next session (S33), single goal

Dataset, harness and write-up published; FR/AR moves out of roadmap.

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

# Session 33 — ____-__-__ — ma-bench

*Scope 2 · Arabic & French*

**Branch:** `docs/s33-release` · **PR:** #___

**Commit subject (pre-written — this is tonight's definition of done):**
```
docs(ma-bench): publish dataset, results and write-up — Scope 2 complete
```

---

## Goal

Dataset live on the Hub, harness in the repo, write-up published. Retrieval exposed as a fourth typed tool on the engine's existing MCP server. README, badge row and landing page updated **with numbers attached**. Tag v2.0.

---

## What happened

-
-
-

## The number

______ · **n = ______** · definition: ______

> If the session produced no number, write "no number this session" rather than leaving this blank.

## Cost

$______

## Blocker hit

```
paste the exact error here
```

Cause: ______

## Dead end

______

> Tag what you tried and abandoned, so you do not re-enter the same rabbit hole in six weeks.

## Decision made

______

> "Chose X over Y because [measurement]" — never "chose X". This sentence is what an ADR is built from.

## Evidence committed

`Published dataset · results · updated public surface`

---

## Next session (—), single goal

— programme complete —

---

<sub>Before closing the laptop: the number carries its `n` · the blocker has the verbatim error · the decision names what you rejected · the next goal is one sentence.</sub>

---

*Built with intention. Measured before it ships.*